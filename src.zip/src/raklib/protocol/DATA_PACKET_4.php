<?php



namespace raklib\protocol;


class DATA_PACKET_4 extends DataPacket{
	public static $ID = 0x84;
}