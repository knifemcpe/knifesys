<?php



namespace raklib\protocol;

class ADVERTISE_SYSTEM extends UNCONNECTED_PONG{
	public static $ID = 0x1d;
}