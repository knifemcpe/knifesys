<?php



namespace pocketmine\inventory;

class BigShapedRecipe extends ShapedRecipe{

}