<?php



namespace raklib\protocol;


class DATA_PACKET_5 extends DataPacket{
	public static $ID = 0x85;
}