<?php



namespace raklib\protocol;


class DATA_PACKET_B extends DataPacket{
	public static $ID = 0x8B;
}