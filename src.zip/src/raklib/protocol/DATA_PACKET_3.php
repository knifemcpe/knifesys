<?php



namespace raklib\protocol;

class DATA_PACKET_3 extends DataPacket{
	public static $ID = 0x83;
}