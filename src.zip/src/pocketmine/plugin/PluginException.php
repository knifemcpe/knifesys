<?php



namespace pocketmine\plugin;

use pocketmine\utils\ServerException;

class PluginException extends ServerException{

}