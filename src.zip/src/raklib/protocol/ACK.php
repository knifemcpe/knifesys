<?php



namespace raklib\protocol;

class ACK extends AcknowledgePacket{
	public static $ID = 0xc0;
}